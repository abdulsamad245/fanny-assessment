
// mui
import { Box } from "@mui/material";

// component
import CartPage from "../components/template/CartPage";


const Cart = () => {
    return (
        <Box>
            <CartPage />
        </Box>
    );
}

export default Cart;