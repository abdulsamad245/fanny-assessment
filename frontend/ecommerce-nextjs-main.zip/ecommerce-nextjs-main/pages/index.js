// mui
import { Box } from '@mui/material'

// component
import HomePage from '../components/template/HomePage'

export default function Home() {

  return (
    <Box>

      <HomePage />

    </Box>
  )
}
